import "./App.css";
import Chatting3 from "./components/Chatting3";
// import Chatting1 from "./components/Chatting1";
// import Chatting2 from "./components/Chatting2";
// import Practice1 from "./components/Practice1";

function App() {
  return (
    <div className="App">
      {/* 실습 1 */}
      {/* <Practice1 /> */}

      {/* 채팅 실습 */}
      {/* 2, 3번 */}
      {/* <Chatting1 /> */}
      {/* 3-1, 3-2, 3-3번 */}
      {/* <Chatting2 /> */}
      {/* 4, 5번 */}
      <Chatting3 />
    </div>
  );
}

export default App;
